var Hello = React.createClass({
  render: function () {
    return (
      <h2>Hola mundo!</h2>
    );
  }
});

ReactDOM.render(
  <Hello />,
  document.getElementById('root')
);