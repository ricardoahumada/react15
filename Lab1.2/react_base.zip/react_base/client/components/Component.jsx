import React from 'react';

const Component = React.createClass({
	render(){
		return (
			<div>
				<h1>Hola React!</h1>
			</div>
		)
	} 
})

export default Component;