import React from 'react';
import {render} from 'react-dom';
import {Router, Route, IndexRoute, browserHistory} from 'react-router';

import Component from './components/Component.jsx';

render(<Component />,document.getElementById('root'));