import React from 'react';
let createReactClass = require('create-react-class');

const Component = createReactClass ({
	render(){
		return (
			<div>
				<h1>Hola React!!!!</h1>
			</div>
		)
	} 
})

export default Component;