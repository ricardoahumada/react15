import React from 'react';
import {render} from 'react-dom';
import {Router, Route, IndexRoute, browserHistory} from 'react-router';

import ComponentPrincipal from './components/Component.jsx';

render(<ComponentPrincipal />,document.getElementById('root'));