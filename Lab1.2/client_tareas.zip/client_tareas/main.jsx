import React from 'react';
import ReactDOM  from 'react-dom';

import { BrowserRouter, Route } from 'react-router-dom'

import ComponentPrincipal from './components/Component.jsx';

if (module.hot) {
  module.hot.accept();
}

const App = () => (
  <BrowserRouter>
    <main>
      <ComponentPrincipal />
    </main>
  </BrowserRouter>
)

ReactDOM.render(<App />, document.getElementById('root'));

