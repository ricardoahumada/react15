import React from 'react';

let createReactClass = require('create-react-class');

const Titulo = createReactClass(
{
	getInitialState:function(){
		console.log("Estoy en el initial state...");
		return {nombre: 'xxx'};
	},
	render(){
		console.log("STATE:",this.state);
		return(<div>
			<h1>{this.props.nombre}</h1>
			
			<button onClick={this.saludar}>Clica</button>

			<span>{this.state.nombre}</span>

			<input onChange={this.updateNombre} name="nombre" value={this.state.nombre}/>
		</div>);
	},

	saludar(e){
		alert("Hola"+this.state.nombre+"!!");
	},

	updateNombre(e){
		console.log("actualizando estado:",e.target);
		this.setState({nombre:e.target.value});
	}
}
);

export default Titulo;