import React from 'react';

export default class Titulo extends React.Component{

	constructor(props, context) {
	    super(props, context);

	    this.state = {
	      nombre: 'xxx'
	    };

	  };

	render(){
		console.log("STATE:",this.state);
		return(<div>
			<h1>{this.props.nombre}</h1>
			
			<button onClick={this.saludar.bind(this)}>Clica</button>

			<span>{this.state.nombre}</span>

			<input onChange={this.updateNombre.bind(this)} name="nombre" value={this.state.nombre}/>
		</div>);
	}

	saludar(e){
		alert("Hola"+this.state.nombre+"!!");
	}

	updateNombre(e){
		console.log("actualizando estado:",e.target);
		this.setState({nombre:e.target.value});
	}
}

Titulo.propTypes={
	nombre:React.PropTypes.string.isRequired
}