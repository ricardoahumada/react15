import React from 'react';
import ListaTareas from './tareas/lista_tareas.jsx';
import ListaProyectos from './proyectos/lista_proyectos.jsx';
import Tarea from '../models/tarea.jsx';
import Proyecto from '../models/proyecto.jsx';

const ComponentPrincipal = React.createClass({
	getInitialState:function(){
		console.log("Estoy en el initial state...");
		return {data:"hola"};
	},
	render:function(){
		console.log("Estoy en el render state...");
		
		let proyectos=[{pid:1,nombre:'proyecto 1'},{pid:2,nombre:'proyecto 2'}];
		let tareas=[
			new Tarea(1,'tarea 1',23,1),
			new Tarea(2,'tarea 2',23,1),
			new Tarea(3,'tarea 3',23,2)			
		];

		return (
			<div>
				<h2>Estado:{this.state.data}</h2>
				<ListaTareas tareas={tareas} />

				<ListaProyectos proyectos={proyectos} />
			</div>
		)
	},
	componentDidMount(){
		console.log("Estoy en el componentDidMount state...",this.state);
		this.state={data:"Adios"};
	}
})

export default ComponentPrincipal;