import React from 'react';

import { BrowserRouter, Route } from 'react-router-dom'

import ListaTareas from './tareas/lista_tareas.jsx';
import ListaProyectos from './proyectos/lista_proyectos.jsx';
import Tarea from '../models/tarea.js';
import Proyecto from '../models/proyecto.js';

import {Button, Icon} from 'react-materialize'
let createReactClass = require('create-react-class');

const ComponentPrincipal = createReactClass({
	getInitialState:function(){
		let proyectos=[{pid:1,nombre:'proyecto 1'},{pid:2,nombre:'proyecto 2'}];
		let tareas=[
			new Tarea(1,'tarea 1',23,1),
			new Tarea(2,'tarea 2',23,1),
			new Tarea(3,'tarea 3',23,2)			
		];

		return {tareas:tareas,proyectos:proyectos};
	},
	render:function(){

		return (
			<div className="container" ref="unDiv">
				{/*<ListaTareas tareas={this.state.tareas} onBorrarTarea={this.handleDeletetarea} />

				<ListaProyectos proyectos={this.state.proyectos} />*/}
				
				<Route path="/tareas" exact render={(props) => ( <ListaTareas tareas={this.state.tareas} onBorrarTarea={this.handleDeletetarea} /> )} />
      			<Route path="/proyectos" render={(props) => (<ListaProyectos proyectos={this.state.proyectos} />)}/>
			</div>
		)
	},
	handleDeletetarea(tid){
		console.log('borrando tarea en componente root',tid);
		let nuevasTareas=this.state.tareas.filter(item=>{return item.tid!=tid;});

		this.setState({tareas:nuevasTareas});
	}

})

export default ComponentPrincipal;