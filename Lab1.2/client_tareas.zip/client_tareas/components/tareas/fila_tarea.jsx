import React from 'react';

const FilaTareas = React.createClass({

	render(){

		return (
			<tr><td>{this.props.unaT.tid}</td><td>{this.props.unaT.descripcion}</td></tr>
		)

	} 

})

export default FilaTareas;
