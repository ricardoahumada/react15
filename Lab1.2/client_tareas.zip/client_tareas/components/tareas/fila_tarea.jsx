import React from 'react';
let createReactClass = require('create-react-class');

const FilaTareas = createReactClass({
	borrarTarea:function(e){
		e.preventDefault();
		console.log('borrando tarea:',this.props.unaT.tid);
		this.props.onBorrarEstaTarea(this.props.unaT.tid);
	},

	render(){

		return (
			<tr><td>{this.props.unaT.tid}</td><td>{this.props.unaT.descripcion}</td><td><a onClick={this.borrarTarea} href="#">Borrar</a></td></tr>
		)

	}

})

export default FilaTareas;
