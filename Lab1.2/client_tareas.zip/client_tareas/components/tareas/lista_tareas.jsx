import React from 'react';
import FilaTareas from './fila_tarea.jsx';
import Tarea from '../../models/tarea.jsx';

const ListaTareas = React.createClass({

	getInitialState(){
		return {valor:""};
	},

	render(){
		let lasFilas=this.props.tareas
			.filter(t=>{return this.state.valor?t.descripcion.indexOf(this.state.valor)>=0:true;})
			.map(t=> {return <FilaTareas unaT={t} key={t.tid}/>;
		});

		return (
			<section className="row">
		        <div className="col s12 m6">
		        	<div className="card blue-grey darken-1">
			            <div className="card-content white-text">
							<h2>Tareas</h2>
							<div><input onChange={this.filterTareas} value={this.state.valor}/></div>
							<table>
								<tbody>
									{lasFilas}
								</tbody>
							</table>		
						</div>
					</div>
				</div>
			</section>
		)

	},
	filterTareas(e){
		console.log("filterTareas:",this.state,e.target.value);
		this.setState({valor:e.target.value});
	}

})

export default ListaTareas;
