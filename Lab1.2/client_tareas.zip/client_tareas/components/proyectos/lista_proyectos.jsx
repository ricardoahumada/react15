import React from 'react';
import FilaProyectos from './fila_proyectos.jsx';

const ListaProyectos = React.createClass({

	getInitialState(){
		return {valor:""};
	},

	render(){
		let lasFilas=this.props.proyectos
		.map(p=> {return <FilaProyectos unaP={p} key={p.pid}/>;});

		return (
			<section className="row">
		        <div className="col s12 m6">
		        	<div className="card blue-grey darken-1">
			            <div className="card-content white-text">
							<h2>Proyectos</h2>
							<div><input onChange={this.filterProyectos} value={this.state.valor}/></div>
							<table>
								<tbody>
									{lasFilas}
								</tbody>
							</table>		
						</div>
					</div>
				</div>
			</section>
		)

	},
	filterProyectos(e){
		console.log("filterProyectos:",this.state,e.target.value);
		this.setState({valor:e.target.value});
	}

})

export default ListaProyectos;
