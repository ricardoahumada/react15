import React from 'react';

let createReactClass = require('create-react-class');

const FilaProyectos = createReactClass({

	render(){

		return (
			<tr><td>{this.props.unaP.pid}</td><td>{this.props.unaP.nombre}</td></tr>
		)

	} 

})

export default FilaProyectos;
