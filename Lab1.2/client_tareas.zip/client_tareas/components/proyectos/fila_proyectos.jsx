import React from 'react';

const FilaProyectos = React.createClass({

	render(){

		return (
			<tr><td>{this.props.unaP.pid}</td><td>{this.props.unaP.nombre}</td></tr>
		)

	} 

})

export default FilaProyectos;
