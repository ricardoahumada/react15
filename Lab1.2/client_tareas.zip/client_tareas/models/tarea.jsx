export default class Tarea{
	constructor(pid, descripcion, tiempo, proyecto){
		this.pid=pid;
		this.descripcion=descripcion;
		this.tiempo=tiempo;
		this.proyecto=proyecto;
	}

}

