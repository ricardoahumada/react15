class Proyecto{
	constructor(pid,nombre){
		this.pid=pid;
		this.nombre=nombre;
	}
}

export default Proyecto;