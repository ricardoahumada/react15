export default class Tarea{
	constructor(tid, descripcion, tiempo, proyecto){
		this.tid=tid;
		this.descripcion=descripcion;
		this.tiempo=tiempo;
		this.proyecto=proyecto;
	}

}

